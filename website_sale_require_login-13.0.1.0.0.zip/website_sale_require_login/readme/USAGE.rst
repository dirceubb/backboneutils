To use this module, you need to:

* Log out.
* Try to buy something.
* You will be forced to log in.
