This module extends the functionality of eCommerce to force users
to login before buying anything in the website  and allow you to get rid of
those duplicated entries of returning unauthenticated users.

If you do not allow external users to sign up, this can serve you to make
checkout available only for those that have a user account, and make some sort
of *members club*.
