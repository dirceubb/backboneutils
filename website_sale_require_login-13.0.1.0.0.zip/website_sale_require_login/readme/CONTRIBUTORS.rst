* Dave Lasley <dave@laslabs.com>
* Oscar Alcala <oscar@vauxoo.com>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Rafael Blasco
  * Jairo Llopis
  * Alexandre Diaz
